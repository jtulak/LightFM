<?php $text = <<<TEXT
hello world $say $something \$boo \\ {$foo->bar[1]}
TEXT;
?>
<?php $text = <<<"TEXT"
hello world $say $something \$boo \\ {$foo->bar[1]}
TEXT;
?>